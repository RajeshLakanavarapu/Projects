@Test
public void testQuantityAdjustment() {
    driver.get("http://your-application-url.com/cart");

    // Adjust quantity
    driver.findElement(By.id("increaseQuantityButton")).click();

    // Validate updated quantity
    String quantity = driver.findElement(By.id("itemQuantity")).getText();
    Assert.assertEquals(quantity, "2");
}
