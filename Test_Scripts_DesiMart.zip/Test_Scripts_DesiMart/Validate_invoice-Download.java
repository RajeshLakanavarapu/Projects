@Test
public void testInvoiceDownload() {
    driver.get("http://your-application-url.com/order-summary");

    // Click download invoice
    driver.findElement(By.id("downloadInvoiceButton")).click();

    // Validate invoice downloaded (assuming UI updates with success message)
    String downloadMessage = driver.findElement(By.id("downloadMessage")).getText();
    Assert.assertEquals(downloadMessage, "Invoice downloaded successfully");
}
