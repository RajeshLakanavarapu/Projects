@Test
public void testCategoryNavigation() {
    driver.get("http://your-application-url.com/shopping");

    // Navigate between categories
    driver.findElement(By.id("categoryElectronics")).click();
    driver.findElement(By.id("categoryClothing")).click();

    // Validate category navigation
    String currentCategory = driver.findElement(By.id("currentCategory")).getText();
    Assert.assertEquals(currentCategory, "Clothing");
}
