class User:
    def __init__(self, firstname="", lastname="", email="",password="PASSINIT", phone="", address="", city="",state="",zipcode=""):
        self.userId = 0
        self.firstname = firstname
        self.lastname = lastname
        self.email = email
        self.password = password
        self.phone = phone
        self.address = address
        self.city = city
        self.state = state
        self.zipcode = zipcode