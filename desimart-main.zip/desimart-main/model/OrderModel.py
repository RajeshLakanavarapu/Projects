class OrderModel:
    def __init__(self, OrderID="", Tax_Price="", Total_Price="", User_ID=""):
        self.OrderID = OrderID
        self.Tax_Price = Tax_Price
        self.Total_Price = Total_Price
        self.User_ID = User_ID