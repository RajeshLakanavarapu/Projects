class cart:
    def __init__(self,productname="",productID="",price="",categoryID="",qty=""):
        self.productname = productname
        self.productID = productID
        self.price = price
        self.categoryID = categoryID
        self.qty = qty
        