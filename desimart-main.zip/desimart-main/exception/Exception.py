from tkinter import messagebox
class Exception:
    def raise_Exception(exception):
        messagebox.showerror("Error",str(exception))